import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Kedua {
    public static void main(String[] args) {
        File f1 = new File("D:\\Kuliah\\Prak_RPLBO\\Latihan\\Javaio\\src\\main\\java\\vincent.txt");
        File f2 = new File("D:\\Kuliah\\Prak_RPLBO\\Latihan\\Javaio\\src\\main\\resources\\vincent.txt");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        String tanggalf1 = sdf.format(f1.lastModified());
        String tanggalf2 = sdf.format(f2.lastModified());
        long ukuranf1 = f1.length();
        long ukuranf2 = f2.length();
        String namaf1 = f1.getName();
        String namaf2 = f2.getName();
        System.out.println("Tanggal file 1: "+tanggalf1);
        System.out.println("Tanggal file 2: "+tanggalf2);
        System.out.println();
        System.out.println("Ukuran file 1: "+ukuranf1);
        System.out.println("Ukuran file 2: "+ukuranf2);
        System.out.println();
        System.out.println("Nama file 1: "+namaf1);
        System.out.println("Nama file 2: "+namaf2);
        System.out.println("====================================");
        if(tanggalf1.equals(tanggalf2) && ukuranf1 == ukuranf2 && namaf1.equals(namaf2)){
            System.out.println("Kedua file adalah identik");
        }else {
            System.out.println("Kedua file tidak identik");
        }
    }
}
