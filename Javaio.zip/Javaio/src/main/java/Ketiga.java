import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
public class Ketiga {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int jumlah = scan.nextInt();
        List<Integer> data = new ArrayList<Integer>();
        int a,b,c;
        for(int i =0; i<jumlah; i++){
            a = scan.nextInt();
            b = scan.nextInt();
            c = scan.nextInt();
            data.add(a);
            data.add(b);
            data.add(c);
        }
//        System.out.println(data.size());
        for(int j=0; j<data.size(); j+=3){
            if((data.get(j) * data.get(j)) + (data.get(j+1) * data.get(j+1)) == (data.get(j+2) * data.get(j+2))){
                System.out.println("ya");
            }
            else {
                System.out.println("tidak");
            }
        }
        for(int isi:data){
            System.out.println(isi);
        }
    }
}
