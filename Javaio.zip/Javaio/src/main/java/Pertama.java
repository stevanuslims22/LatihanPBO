import java.io.*;
import java.text.SimpleDateFormat;

public class Pertama {
    public static void main(String[] args) {
        String dirname = "D:\\Kuliah\\Prak_RPLBO\\Latihan\\Javaio\\src\\main\\java";
        File f1 = new File(dirname);
        if (f1.isDirectory()) {
            System.out.println("Directory of " + dirname);
            String s[] = f1.list();
            for (int i=0; i < s.length; i++) {
                File f = new File(dirname + "/" + s[i]);
                if (f.isDirectory()) {
                    System.out.println(s[i] + " is a directory");
                } else {
                    SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
                    System.out.println("====================="+s[i] + "=====================");
                    System.out.println("Tanggal Modified: " + sdf.format(f.lastModified()));
                    System.out.println("Ukuran File: "+f.length()+" Bytes");
                    System.out.println(f.canRead()? "File is: Readable":"File is: not Readable");
                    System.out.println(f.canWrite()? "File is: Writeable":"File is: not Writeable");
                    if(f.canRead() && !f.canWrite()){
                        System.out.println("File is: Readonly");
                    }else {
                        System.out.println("File is: not Readonly");
                    }
                    System.out.println(f.isHidden()? "File is: Hidden":"File is: not Hidden");
                    System.out.println(f.canExecute()? "File is: Executable":"File is: not Executable");
                    System.out.println();
                }
            }
        } else {
            System.out.println(dirname + " is not a directory");
        }
    }
}
