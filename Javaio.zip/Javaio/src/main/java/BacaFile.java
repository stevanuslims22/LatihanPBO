import java.io.*;
public class BacaFile {
    public static void main(String[] args) {
        String line = "", fileContent = "";
        try{
            BufferedReader fileInput = new BufferedReader(new FileReader(new File("D:/Kuliah/Prak_RPLBO/Latihan/Javaio/src/main/resources/vincent.txt")));
            line = fileInput.readLine();
            fileContent = line + "\n";
            while (line != null){
                line = fileInput.readLine();
                if(line != null){
                    fileContent += line + "\n";
                }
            }
            fileInput.close();
        }
        catch (EOFException eofe){
            System.out.println("No more Lines to read.");
            System.exit(0);
        }
        catch (IOException ioe){
            System.out.println("Error reading file.");
            System.exit(0);
        }
        System.out.println(fileContent);
    }
}
